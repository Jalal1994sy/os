
import TeamManagementPage from "@/components/landing/features/TeamManagementPage";

export default function Page() {
  return <TeamManagementPage />;
}
