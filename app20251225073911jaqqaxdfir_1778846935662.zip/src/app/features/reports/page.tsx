
import ReportsPage from "@/components/landing/features/ReportsPage";

export default function Page() {
  return <ReportsPage />;
}
