
import NotificationsPage from "@/components/landing/features/NotificationsPage";

export default function Page() {
  return <NotificationsPage />;
}
