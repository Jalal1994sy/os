
import SecurityPage from "@/components/landing/features/SecurityPage";

export default function Page() {
  return <SecurityPage />;
}
