
import InvoicesFeaturePage from "@/components/landing/features/InvoicesFeaturePage";

export default function Page() {
  return <InvoicesFeaturePage />;
}
