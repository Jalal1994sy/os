
import { redirect } from 'next/navigation';
import DashboardClient from '@/components/dashboard/DashboardClient';

export default function DashboardPage() {
  return <DashboardClient />;
}
