
import UsersManagementClient from '@/components/admin/UsersManagementClient';

export default function AdminUsersPage() {
  return <UsersManagementClient />;
}
