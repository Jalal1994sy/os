
'use client';

import { useState, useEffect } from 'react';
import { useAuth } from '@/components/auth/AuthProvider';
import { useRouter } from 'next/navigation';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  MapPin, 
  Clock, 
  DollarSign,
  ArrowLeft,
  Navigation,
  Calendar,
  CheckCircle2,
  XCircle,
  AlertCircle,
  RefreshCw,
  FileText,
  Download,
  Share2,
  QrCode
} from 'lucide-react';
import Link from 'next/link';
import { api } from '@/lib/api-client';
import { toast } from 'sonner';

interface Invoice {
  id: number;
  invoice_number: string;
  total_tvac: number;
  status: string;
  payment_status: string;
  invoice_date: string;
}

interface Trip {
  id: number;
  start_time: string;
  end_time: string;
  start_address: string;
  end_address: string;
  distance_km: number;
  duration_minutes: number;
  price: number;
  status: string;
  chiron_trip_id: string | null;
  chiron_sync_attempts: number;
  invoice: Invoice | null;
}

export default function TripsPage() {
  const { user, isLoading } = useAuth();
  const router = useRouter();
  const [trips, setTrips] = useState<Trip[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'completed' | 'pending' | 'failed'>('all');
  const [downloadingId, setDownloadingId] = useState<number | null>(null);

  useEffect(() => {
    if (!isLoading && !user) {
      router.push('/login');
    }
  }, [user, isLoading, router]);

  const fetchTrips = async () => {
    setLoading(true);
    try {
      const data = await api.get<Trip[]>('/trips');
      setTrips(data);
    } catch (error: any) {
      toast.error(error.message || 'فشل تحميل الرحلات');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchTrips();
    }
  }, [user]);

  const handleDownloadInvoice = async (tripId: number) => {
    setDownloadingId(tripId);
    try {
      const response = await fetch(`/next_api/trips/generate-invoice?id=${tripId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('فشل تحميل الفاتورة');
      }

      const shareUrl = response.headers.get('X-Share-URL');
      const qrCodeUrl = response.headers.get('X-QR-Code-URL');

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Factuur-Rit-${tripId}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      if (shareUrl) {
        toast.success('تم تحميل الفاتورة بنجاح', {
          description: 'يمكنك مشاركة الرابط مع العميل',
          action: {
            label: 'نسخ الرابط',
            onClick: () => {
              navigator.clipboard.writeText(shareUrl);
              toast.success('تم نسخ رابط الفاتورة');
            }
          }
        });
      } else {
        toast.success('تم تحميل الفاتورة بنجاح');
      }

      // تحديث قائمة الرحلات لإظهار الفاتورة الجديدة
      fetchTrips();
    } catch (error: any) {
      console.error('Error downloading invoice:', error);
      toast.error('فشل تحميل الفاتورة');
    } finally {
      setDownloadingId(null);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
      case 'success':
        return (
          <Badge className="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 border-0">
            <CheckCircle2 className="w-3 h-3 ml-1" />
            مكتملة
          </Badge>
        );
      case 'pending':
        return (
          <Badge className="bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400 border-0">
            <AlertCircle className="w-3 h-3 ml-1" />
            قيد المزامنة
          </Badge>
        );
      case 'failed':
        return (
          <Badge className="bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400 border-0">
            <XCircle className="w-3 h-3 ml-1" />
            فشلت
          </Badge>
        );
      default:
        return (
          <Badge className="bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-400 border-0">
            {status}
          </Badge>
        );
    }
  };

  const getInvoiceStatusBadge = (status: string) => {
    const statusConfig = {
      draft: { label: 'مسودة', className: 'bg-gray-100 text-gray-700 dark:bg-gray-900/30 dark:text-gray-400' },
      sent: { label: 'مرسلة', className: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' },
      paid: { label: 'مدفوعة', className: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' },
      cancelled: { label: 'ملغاة', className: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' },
      overdue: { label: 'متأخرة', className: 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400' }
    };

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.draft;
    return <Badge className={`${config.className} border-0`}>{config.label}</Badge>;
  };

  const filteredTrips = trips.filter(trip => {
    if (filter === 'all') return true;
    return trip.status === filter;
  });

  if (isLoading || loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-xl bg-white/70 dark:bg-slate-900/70 border-b border-slate-200/50 dark:border-slate-800/50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <Button variant="ghost" size="icon" className="rounded-2xl">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              إدارة الرحلات
            </h1>
            <Button 
              variant="ghost" 
              size="icon" 
              className="rounded-2xl"
              onClick={fetchTrips}
            >
              <RefreshCw className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Filters */}
        <div className="flex gap-3 mb-6 overflow-x-auto pb-2">
          <Button
            onClick={() => setFilter('all')}
            variant={filter === 'all' ? 'default' : 'outline'}
            className="rounded-2xl whitespace-nowrap"
          >
            الكل ({trips.length})
          </Button>
          <Button
            onClick={() => setFilter('completed')}
            variant={filter === 'completed' ? 'default' : 'outline'}
            className="rounded-2xl whitespace-nowrap"
          >
            مكتملة ({trips.filter(t => t.status === 'completed' || t.status === 'success').length})
          </Button>
          <Button
            onClick={() => setFilter('pending')}
            variant={filter === 'pending' ? 'default' : 'outline'}
            className="rounded-2xl whitespace-nowrap"
          >
            قيد المزامنة ({trips.filter(t => t.status === 'pending').length})
          </Button>
          <Button
            onClick={() => setFilter('failed')}
            variant={filter === 'failed' ? 'default' : 'outline'}
            className="rounded-2xl whitespace-nowrap"
          >
            فشلت ({trips.filter(t => t.status === 'failed').length})
          </Button>
        </div>

        {/* Trips List */}
        <div className="space-y-4">
          {filteredTrips.length === 0 ? (
            <Card className="p-12 rounded-3xl border-0 shadow-xl shadow-slate-200/50 dark:shadow-slate-900/50 bg-gradient-to-br from-white to-slate-50 dark:from-slate-800 dark:to-slate-900">
              <div className="text-center">
                <div className="w-20 h-20 rounded-3xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto mb-4">
                  <MapPin className="w-10 h-10 text-slate-400" />
                </div>
                <p className="text-slate-600 dark:text-slate-400">لا توجد رحلات</p>
              </div>
            </Card>
          ) : (
            filteredTrips.map((trip) => (
              <Card 
                key={trip.id}
                className="p-6 rounded-3xl border-0 shadow-xl shadow-slate-200/50 dark:shadow-slate-900/50 bg-gradient-to-br from-white to-slate-50 dark:from-slate-800 dark:to-slate-900 hover:scale-[1.02] transition-transform duration-300"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-blue-500/30">
                      <MapPin className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <span className="font-bold text-slate-900 dark:text-white">
                          رحلة #{trip.id}
                        </span>
                        {getStatusBadge(trip.status)}
                        {trip.invoice && getInvoiceStatusBadge(trip.invoice.status)}
                      </div>
                      <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                        <Calendar className="w-4 h-4" />
                        {new Date(trip.start_time).toLocaleDateString('ar-SA', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </div>
                    </div>
                  </div>
                  <div className="text-left">
                    <div className="text-2xl font-bold bg-gradient-to-r from-green-600 to-green-700 bg-clip-text text-transparent">
                      €{trip.price.toFixed(2)}
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-start gap-3 p-3 rounded-2xl bg-slate-100 dark:bg-slate-800">
                    <div className="w-8 h-8 rounded-xl bg-green-500 flex items-center justify-center flex-shrink-0">
                      <MapPin className="w-4 h-4 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-slate-600 dark:text-slate-400 mb-1">نقطة البداية</p>
                      <p className="text-sm font-medium text-slate-900 dark:text-white truncate">
                        {trip.start_address || 'موقع غير محدد'}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-500 mt-1">
                        {new Date(trip.start_time).toLocaleTimeString('ar-SA', {
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 p-3 rounded-2xl bg-slate-100 dark:bg-slate-800">
                    <div className="w-8 h-8 rounded-xl bg-red-500 flex items-center justify-center flex-shrink-0">
                      <MapPin className="w-4 h-4 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-slate-600 dark:text-slate-400 mb-1">نقطة النهاية</p>
                      <p className="text-sm font-medium text-slate-900 dark:text-white truncate">
                        {trip.end_address || 'موقع غير محدد'}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-500 mt-1">
                        {new Date(trip.end_time).toLocaleTimeString('ar-SA', {
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 mt-4">
                  <div className="p-3 rounded-2xl bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800">
                    <div className="flex items-center gap-2 mb-1">
                      <Navigation className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                      <span className="text-xs text-blue-600 dark:text-blue-400">المسافة</span>
                    </div>
                    <p className="text-lg font-bold text-blue-900 dark:text-blue-100">
                      {trip.distance_km.toFixed(2)} كم
                    </p>
                  </div>

                  <div className="p-3 rounded-2xl bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800">
                    <div className="flex items-center gap-2 mb-1">
                      <Clock className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                      <span className="text-xs text-purple-600 dark:text-purple-400">المدة</span>
                    </div>
                    <p className="text-lg font-bold text-purple-900 dark:text-purple-100">
                      {trip.duration_minutes} دقيقة
                    </p>
                  </div>
                </div>

                {trip.invoice && (
                  <div className="mt-4 p-4 rounded-2xl bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border border-green-200 dark:border-green-800">
                    <div className="flex items-center gap-2 mb-2">
                      <FileText className="w-5 h-5 text-green-600 dark:text-green-400" />
                      <span className="font-bold text-green-900 dark:text-green-100">
                        فاتورة الرحلة
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-sm mb-3">
                      <div>
                        <p className="text-xs text-green-600 dark:text-green-400">رقم الفاتورة</p>
                        <p className="font-mono text-green-900 dark:text-green-100">{trip.invoice.invoice_number}</p>
                      </div>
                      <div>
                        <p className="text-xs text-green-600 dark:text-green-400">المبلغ</p>
                        <p className="font-bold text-green-900 dark:text-green-100">€{trip.invoice.total_tvac.toFixed(2)}</p>
                      </div>
                    </div>
                    <Button
                      onClick={() => handleDownloadInvoice(trip.id)}
                      disabled={downloadingId === trip.id}
                      className="w-full rounded-2xl bg-gradient-to-r from-green-500 to-emerald-600"
                      size="sm"
                    >
                      {downloadingId === trip.id ? (
                        <>
                          <RefreshCw className="w-4 h-4 ml-2 animate-spin" />
                          جاري التحميل...
                        </>
                      ) : (
                        <>
                          <Download className="w-4 h-4 ml-2" />
                          تحميل الفاتورة
                        </>
                      )}
                    </Button>
                  </div>
                )}

                {!trip.invoice && (
                  <div className="mt-4">
                    <Button
                      onClick={() => handleDownloadInvoice(trip.id)}
                      disabled={downloadingId === trip.id}
                      variant="outline"
                      className="w-full rounded-2xl"
                    >
                      {downloadingId === trip.id ? (
                        <>
                          <RefreshCw className="w-4 h-4 ml-2 animate-spin" />
                          جاري إنشاء الفاتورة...
                        </>
                      ) : (
                        <>
                          <FileText className="w-4 h-4 ml-2" />
                          إنشاء فاتورة
                        </>
                      )}
                    </Button>
                  </div>
                )}

                {trip.chiron_trip_id && (
                  <div className="mt-4 p-3 rounded-2xl bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800">
                    <p className="text-xs text-green-600 dark:text-green-400 mb-1">معرف Chiron</p>
                    <p className="text-sm font-mono text-green-900 dark:text-green-100">
                      {trip.chiron_trip_id}
                    </p>
                  </div>
                )}

                {trip.status === 'failed' && trip.chiron_sync_attempts > 0 && (
                  <div className="mt-4 p-3 rounded-2xl bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800">
                    <p className="text-xs text-red-600 dark:text-red-400">
                      فشلت المزامنة بعد {trip.chiron_sync_attempts} محاولة
                    </p>
                  </div>
                )}
              </Card>
            ))
          )}
        </div>
      </main>
    </div>
  );
}
