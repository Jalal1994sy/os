
'use client';

import { useAuth } from '@/components/auth/AuthProvider';
import { useRouter, usePathname } from 'next/navigation';
import { useEffect, useState, useCallback } from 'react';
import {
  MapPin, FileText, TestTube, LogOut, Bell, MessageSquare, BarChart3, Loader2, User,
} from 'lucide-react';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';
import { ThemeToggle } from '@/components/ThemeToggle';
import { api } from '@/lib/api-client';
import { motion, AnimatePresence } from 'framer-motion';
import { LanguageProvider, useLanguage } from '@/contexts/LanguageContext';
import { driverTranslations } from '@/locales/driver';
import Image from 'next/image';
import DriverSplashScreen from '@/components/DriverSplashScreen';
import VehicleSelectionModal from '@/components/VehicleSelectionModal';
import PWAInstallPrompt from '@/components/PWAInstallPrompt';
import MobileStatusBar from '@/components/MobileStatusBar';

const LOGO_URL = 'https://cdn.chat2db-ai.com/app/avatar/custom/16eda623-2b94-41ea-8390-395dcb708494_737955.png';

interface DriverInfo {
  driver: { id: number; full_name: string; phone: string; status: string; company_id: number };
  company: { id: number; name: string; chiron_mode: string };
}

interface VehicleData {
  vehicles: Array<{ id: number; brand: string; model: string; plate_number: string }>;
  current_vehicle_id: number | null;
  driver_id: number;
}

function GoldParticle({ index }: { index: number }) {
  const size = Math.random() * 3 + 1.5;
  const duration = Math.random() * 12 + 8;
  const delay = Math.random() * 6;
  const x = Math.random() * 100;
  return (
    <motion.div
      className="absolute rounded-full pointer-events-none"
      style={{
        width: size, height: size,
        left: `${x}%`, bottom: '-6px',
        background: index % 2 === 0 ? 'rgba(212,175,55,0.5)' : 'rgba(255,215,0,0.35)',
        boxShadow: `0 0 ${size * 2}px rgba(212,175,55,0.7)`,
      }}
      animate={{ y: [0, -700], opacity: [0, 0.7, 0.7, 0], scale: [0, 1, 1, 0] }}
      transition={{ duration, delay, repeat: Infinity, ease: 'easeInOut' }}
    />
  );
}

function NavItem({
  href, icon: Icon, label, isActive, badge, gradient, glow, index,
}: {
  href: string; icon: React.ElementType; label: string; isActive: boolean;
  badge?: number; gradient: string; glow: string; index: number;
}) {
  return (
    <Link href={href} className="flex-1 min-w-0">
      <motion.div
        whileTap={{ scale: 0.88 }}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: index * 0.07, type: 'spring', stiffness: 400, damping: 17 }}
        className="relative"
      >
        <AnimatePresence>
          {isActive && (
            <motion.div
              layoutId="goldActiveTab"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ type: 'spring', stiffness: 400, damping: 25 }}
              className="absolute inset-0 rounded-[1.25rem] overflow-hidden"
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${gradient} opacity-90`} />
              <div className="absolute inset-0 backdrop-blur-xl bg-black/10" />
              <motion.div
                animate={{ opacity: [0.4, 0.8, 0.4], scale: [1, 1.05, 1] }}
                transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                className="absolute inset-0 rounded-[1.25rem]"
                style={{ boxShadow: `0 0 24px ${glow}, inset 0 0 12px ${glow}` }}
              />
              <motion.div
                animate={{ x: ['-100%', '100%'] }}
                transition={{ duration: 2.5, repeat: Infinity, ease: 'linear' }}
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/25 to-transparent"
                style={{ transform: 'skewX(-20deg)' }}
              />
            </motion.div>
          )}
        </AnimatePresence>

        <div className="relative flex flex-col items-center gap-1 p-2">
          <motion.div
            animate={{ scale: isActive ? 1.15 : 1, y: isActive ? -2 : 0 }}
            transition={{ type: 'spring', stiffness: 400, damping: 17 }}
            className="relative"
          >
            {isActive && (
              <motion.div
                animate={{ opacity: [0.3, 0.6, 0.3], scale: [1, 1.3, 1] }}
                transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                className="absolute inset-0 blur-xl rounded-full"
                style={{ background: glow }}
              />
            )}
            <Icon
              className="relative w-5 h-5 transition-all duration-300"
              style={
                isActive
                  ? { color: 'white', filter: 'drop-shadow(0 2px 8px rgba(255,255,255,0.5))' }
                  : { color: 'rgba(212,175,55,0.75)' }
              }
              strokeWidth={isActive ? 2.5 : 2}
            />
            <AnimatePresence>
              {badge && badge > 0 && (
                <motion.div
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0, opacity: 0 }}
                  transition={{ type: 'spring', stiffness: 500, damping: 25 }}
                  className="absolute -top-1 -right-1"
                >
                  <Badge className="h-4 min-w-4 flex items-center justify-center p-0 px-1 bg-gradient-to-br from-red-500 to-pink-600 text-white text-[9px] font-bold border-2 border-slate-900 shadow-lg">
                    {badge > 9 ? '9+' : badge}
                  </Badge>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>

          <motion.span
            animate={{ opacity: isActive ? 1 : 0.8, scale: isActive ? 1.05 : 1 }}
            transition={{ duration: 0.2 }}
            className="text-[8.5px] font-semibold transition-all duration-300 truncate max-w-full px-0.5"
            style={isActive ? { color: 'white' } : { color: 'rgba(212,175,55,0.75)' }}
          >
            {label}
          </motion.span>

          <AnimatePresence>
            {isActive && (
              <motion.div
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0, opacity: 0 }}
                className="absolute -bottom-0.5"
              >
                <motion.div
                  animate={{ scale: [1, 1.4, 1], opacity: [0.8, 1, 0.8] }}
                  transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                  className="w-1 h-1 rounded-full bg-white shadow-[0_0_8px_rgba(255,255,255,0.8)]"
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </Link>
  );
}

function DriverLayoutContent({ children }: { children: React.ReactNode }) {
  const { user, isLoading, logout } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const { language, setLanguage } = useLanguage();
  const t = driverTranslations[language];
  const [driverInfo, setDriverInfo] = useState<DriverInfo | null>(null);
  const [loadingDriver, setLoadingDriver] = useState(true);
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  const [unreadMessages, setUnreadMessages] = useState(0);
  const [showSplash, setShowSplash] = useState(true);
  const [showVehicleSelection, setShowVehicleSelection] = useState(false);
  const [vehicleCheckDone, setVehicleCheckDone] = useState(false);
  const [particles] = useState(() => Array.from({ length: 12 }, (_, i) => i));
  const [isStandalone, setIsStandalone] = useState(false);

  useEffect(() => {
    setIsStandalone(window.matchMedia('(display-mode: standalone)').matches);
  }, []);

  useEffect(() => {
    if (!isLoading && !user) router.push('/driver-login');
  }, [user, isLoading, router]);

  useEffect(() => {
    const loadDriverInfo = async () => {
      if (!user) return;
      try {
        const info = await api.get<DriverInfo>('/drivers/me');
        setDriverInfo(info);
      } catch (error) {
        console.error('Error loading driver info:', error);
      } finally {
        setLoadingDriver(false);
      }
    };
    if (user) loadDriverInfo();
  }, [user]);

  useEffect(() => {
    const checkVehicleSelection = async () => {
      if (!user || showSplash || vehicleCheckDone) return;
      try {
        const data = await api.get<VehicleData>('/drivers/vehicles');
        if (data.vehicles.length > 1 && !data.current_vehicle_id) {
          setShowVehicleSelection(true);
        } else if (data.vehicles.length === 1 && !data.current_vehicle_id) {
          await api.put('/drivers/vehicles', { vehicle_id: data.vehicles[0].id });
        }
      } catch (error) {
        console.error('Error checking vehicle selection:', error);
      } finally {
        setVehicleCheckDone(true);
      }
    };
    checkVehicleSelection();
  }, [user, showSplash, vehicleCheckDone]);

  const loadUnreadCounts = useCallback(async () => {
    if (!user) return;
    try {
      const [notifications, messages] = await Promise.all([
        api.get<any[]>('/notifications/driver'),
        api.get<any[]>('/messages/driver'),
      ]);
      setUnreadNotifications(notifications.filter(n => !n.is_read).length);
      setUnreadMessages(messages.filter(m => !m.is_read).length);
    } catch (error) {
      console.error('Error loading counts:', error);
    }
  }, [user]);

  useEffect(() => {
    if (user) {
      loadUnreadCounts();
      const interval = setInterval(loadUnreadCounts, 60000);
      return () => clearInterval(interval);
    }
  }, [user, loadUnreadCounts]);

  // isReady: auth completed AND (no user OR driver info loaded)
  const isReady = !isLoading && (!user || !loadingDriver);

  if (showSplash) {
    return (
      <DriverSplashScreen
        isReady={isReady}
        onComplete={() => setShowSplash(false)}
      />
    );
  }

  if (!user || !driverInfo) {
    return (
      <div className="flex items-center justify-center min-h-screen" style={{ background: 'linear-gradient(135deg, #020817 0%, #0a0f1e 100%)' }}>
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}>
          <Loader2 className="w-10 h-10" style={{ color: '#d4af37' }} />
        </motion.div>
      </div>
    );
  }

  const navItems = [
    { href: '/driver/taximeter', icon: MapPin, label: t.taximeter, gradient: 'from-amber-500 to-yellow-600', glow: 'rgba(212,175,55,0.7)' },
    { href: '/driver/trips', icon: FileText, label: t.trips, gradient: 'from-emerald-500 to-teal-600', glow: 'rgba(16,185,129,0.7)' },
    { href: '/driver/summary', icon: BarChart3, label: t.summary, gradient: 'from-violet-500 to-purple-600', glow: 'rgba(139,92,246,0.7)' },
    { href: '/driver/profile', icon: User, label: t.profile, gradient: 'from-cyan-500 to-blue-600', glow: 'rgba(34,211,238,0.7)' },
    { href: '/driver/messages', icon: MessageSquare, label: t.messages, gradient: 'from-rose-500 to-pink-600', glow: 'rgba(244,63,94,0.7)', badge: unreadMessages },
    { href: '/driver/notifications', icon: Bell, label: t.notifications, gradient: 'from-blue-500 to-indigo-600', glow: 'rgba(99,102,241,0.7)', badge: unreadNotifications },
    { href: '/driver/test', icon: TestTube, label: t.test, gradient: 'from-orange-500 to-amber-600', glow: 'rgba(249,115,22,0.7)' },
  ];

  const safeAreaTop = isStandalone ? 'env(safe-area-inset-top, 44px)' : '0px';

  return (
    <div
      className="min-h-screen min-h-dvh"
      style={{ background: 'linear-gradient(135deg, #020817 0%, #0a0f1e 40%, #050d1a 70%, #020817 100%)' }}
    >
      <AnimatePresence>
        {showVehicleSelection && (
          <VehicleSelectionModal language={language} onVehicleSelected={() => setShowVehicleSelection(false)} />
        )}
      </AnimatePresence>

      <MobileStatusBar />

      {/* جسيمات الذهب المتطايرة */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        {particles.map((i) => <GoldParticle key={i} index={i} />)}
      </div>

      {/* شبكة الخلفية */}
      <div
        className="fixed inset-0 pointer-events-none z-0 opacity-[0.03]"
        style={{
          backgroundImage: `linear-gradient(rgba(212,175,55,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(212,175,55,0.5) 1px, transparent 1px)`,
          backgroundSize: '40px 40px',
        }}
      />

      {/* توهجات الخلفية */}
      <motion.div
        className="fixed rounded-full pointer-events-none blur-3xl z-0"
        style={{ width: 400, height: 400, top: '-10%', left: '-10%', background: 'rgba(212,175,55,0.08)' }}
        animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.5, 0.3] }}
        transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div
        className="fixed rounded-full pointer-events-none blur-3xl z-0"
        style={{ width: 300, height: 300, bottom: '10%', right: '-5%', background: 'rgba(184,142,4,0.06)' }}
        animate={{ scale: [1, 1.3, 1], opacity: [0.2, 0.4, 0.2] }}
        transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut', delay: 3 }}
      />

      {/* الهيدر */}
      <motion.header
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, type: 'spring', stiffness: 120 }}
        className="sticky top-0 z-50"
        style={{
          background: 'rgba(2,8,23,0.95)',
          backdropFilter: 'blur(24px)',
          borderBottom: '1px solid rgba(212,175,55,0.15)',
          boxShadow: '0 4px 32px rgba(0,0,0,0.5)',
          paddingTop: `max(0.75rem, ${safeAreaTop})`,
        }}
      >
        <div className="px-4 pb-3">
          <div className="flex items-center justify-between gap-2">
            {/* معلومات السائق — قابلة للنقر للانتقال للملف الشخصي */}
            <Link
              href="/driver/profile"
              className="flex items-center gap-3 active:opacity-80 transition-opacity min-w-0 flex-1"
              aria-label={t.myProfile}
            >
              <motion.div
                whileTap={{ scale: 0.9 }}
                className="relative w-10 h-10 rounded-2xl overflow-hidden flex-shrink-0"
                style={{ border: '1px solid rgba(212,175,55,0.35)', background: 'rgba(15,23,42,0.6)' }}
              >
                <Image src={LOGO_URL} alt="Jouw Driver" fill className="object-contain p-0.5" priority />
              </motion.div>
              <div className="min-w-0">
                <h1
                  className="text-sm font-bold tracking-wide truncate"
                  style={{
                    background: 'linear-gradient(90deg, #b8860b, #d4af37, #ffd700)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                  }}
                >
                  {driverInfo?.driver?.full_name}
                </h1>
                <div className="flex items-center gap-1.5">
                  <motion.div
                    animate={{ opacity: [1, 0.4, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                    style={{ background: '#22c55e', boxShadow: '0 0 6px rgba(34,197,94,0.8)' }}
                  />
                  <p className="text-xs truncate" style={{ color: 'rgba(212,175,55,0.7)' }}>
                    {driverInfo?.company?.name}
                  </p>
                </div>
              </div>
            </Link>

            {/* أدوات الهيدر: اللغة + الوضع الليلي + تسجيل الخروج */}
            <div className="flex items-center gap-1.5 flex-shrink-0">
              {/* مبدل اللغة */}
              <div
                className="flex gap-0.5 p-0.5 rounded-xl"
                style={{ background: 'rgba(212,175,55,0.08)', border: '1px solid rgba(212,175,55,0.18)' }}
              >
                {(['nl', 'fr', 'ar'] as const).map((lang) => (
                  <motion.button
                    key={lang}
                    onClick={() => setLanguage(lang)}
                    whileTap={{ scale: 0.9 }}
                    className="px-2.5 py-1 rounded-lg text-xs font-semibold transition-all duration-300"
                    style={
                      language === lang
                        ? { background: 'linear-gradient(135deg, #b8860b, #d4af37)', color: '#1a1200', boxShadow: '0 2px 8px rgba(212,175,55,0.4)' }
                        : { color: 'rgba(212,175,55,0.7)' }
                    }
                  >
                    {lang.toUpperCase()}
                  </motion.button>
                ))}
              </div>

              {/* زر تبديل الوضع الليلي بنمط السائق */}
              <ThemeToggle variant="driver" />

              {/* زر تسجيل الخروج */}
              <motion.button
                whileTap={{ scale: 0.85 }}
                onClick={logout}
                className="w-9 h-9 rounded-xl flex items-center justify-center transition-all"
                style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.25)' }}
                title={t.logout}
              >
                <LogOut className="w-4 h-4 text-red-400" />
              </motion.button>
            </div>
          </div>
        </div>
      </motion.header>

      {/* المحتوى الرئيسي */}
      <main className="relative z-10 pb-32">
        <motion.div
          key={pathname}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, ease: 'easeOut' }}
        >
          {children}
        </motion.div>
      </main>

      {/* شريط التنقل السفلي */}
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.7, type: 'spring', stiffness: 100, delay: 0.2 }}
        className="fixed bottom-0 left-0 right-0 z-50 px-2"
        style={{ paddingBottom: 'max(0.75rem, env(safe-area-inset-bottom))' }}
      >
        <nav className="mx-auto max-w-2xl">
          <div
            className="rounded-[2rem] p-1.5"
            style={{
              background: 'rgba(2,8,23,0.97)',
              backdropFilter: 'blur(32px)',
              border: '1px solid rgba(212,175,55,0.18)',
              boxShadow: '0 -4px 32px rgba(0,0,0,0.6), 0 0 0 1px rgba(212,175,55,0.06)',
            }}
          >
            <div className="flex items-center justify-around gap-0.5">
              {navItems.map((item, index) => (
                <NavItem
                  key={item.href}
                  href={item.href}
                  icon={item.icon}
                  label={item.label}
                  isActive={pathname === item.href}
                  badge={item.badge}
                  gradient={item.gradient}
                  glow={item.glow}
                  index={index}
                />
              ))}
            </div>
          </div>
        </nav>
      </motion.div>

      <PWAInstallPrompt />
    </div>
  );
}

export default function DriverLayout({ children }: { children: React.ReactNode }) {
  return (
    <LanguageProvider>
      <DriverLayoutContent>{children}</DriverLayoutContent>
    </LanguageProvider>
  );
}
