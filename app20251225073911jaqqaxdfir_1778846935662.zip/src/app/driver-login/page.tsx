
'use client';

import React, { useState, Suspense, useCallback, useEffect } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { motion, AnimatePresence } from 'framer-motion';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/components/auth/AuthProvider';
import { Loader2, Lock, Phone, ChevronRight, Shield, Zap, Star } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { driverTranslations } from '@/locales/driver';
import Image from 'next/image';
import { api } from '@/lib/api-client';

const LOGO_URL =
  'https://cdn.chat2db-ai.com/app/avatar/custom/16eda623-2b94-41ea-8390-395dcb708494_737955.png';

function Particle({ index }: { index: number }) {
  const size = Math.random() * 4 + 2;
  const duration = Math.random() * 15 + 10;
  const delay = Math.random() * 8;
  const x = Math.random() * 100;

  return (
    <motion.div
      className="absolute rounded-full pointer-events-none"
      style={{
        width: size,
        height: size,
        left: `${x}%`,
        bottom: '-10px',
        background:
          index % 3 === 0
            ? 'rgba(212,175,55,0.6)'
            : index % 3 === 1
            ? 'rgba(255,215,0,0.4)'
            : 'rgba(184,142,4,0.5)',
        boxShadow: `0 0 ${size * 2}px currentColor`,
      }}
      animate={{
        y: [0, -900],
        x: [0, (Math.random() - 0.5) * 120],
        opacity: [0, 0.8, 0.8, 0],
        scale: [0, 1, 1, 0],
      }}
      transition={{
        duration,
        delay,
        repeat: Infinity,
        ease: 'easeInOut',
      }}
    />
  );
}

function AnimatedGrid() {
  return (
    <motion.div
      className="absolute inset-0 pointer-events-none"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 2 }}
    >
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage: `
            linear-gradient(rgba(212,175,55,0.5) 1px, transparent 1px),
            linear-gradient(90deg, rgba(212,175,55,0.5) 1px, transparent 1px)
          `,
          backgroundSize: '40px 40px',
        }}
      />
    </motion.div>
  );
}

function GlowOrb({
  color,
  size,
  top,
  left,
  delay,
}: {
  color: string;
  size: number;
  top: string;
  left: string;
  delay: number;
}) {
  return (
    <motion.div
      className="absolute rounded-full pointer-events-none blur-3xl"
      style={{ width: size, height: size, top, left, background: color }}
      animate={{
        scale: [1, 1.3, 1],
        opacity: [0.3, 0.6, 0.3],
      }}
      transition={{ duration: 6, delay, repeat: Infinity, ease: 'easeInOut' }}
    />
  );
}

function FeatureBadge({
  icon: Icon,
  label,
  delay,
}: {
  icon: React.ElementType;
  label: string;
  delay: number;
}) {
  return (
    <motion.div
      className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-yellow-500/20 bg-yellow-500/5 backdrop-blur-sm"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.5 }}
    >
      <Icon className="w-3.5 h-3.5 text-yellow-400" />
      <span className="text-xs text-slate-300 font-medium">{label}</span>
    </motion.div>
  );
}

function LanguageToggle() {
  const { language, setLanguage } = useLanguage();
  return (
    <motion.div
      className="flex items-center gap-1 p-1 rounded-xl bg-white/5 border border-white/10 backdrop-blur-sm"
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
    >
      {(['nl', 'fr', 'ar'] as const).map((lang) => (
        <button
          key={lang}
          onClick={() => setLanguage(lang)}
          className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all duration-300 ${
            language === lang
              ? 'bg-yellow-600 text-white shadow-lg shadow-yellow-500/30'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          {lang.toUpperCase()}
        </button>
      ))}
    </motion.div>
  );
}

function AnimatedInput({
  id,
  type,
  placeholder,
  icon: Icon,
  register,
  error,
  disabled,
  delay,
}: {
  id: string;
  type: string;
  placeholder: string;
  icon: React.ElementType;
  register: any;
  error?: string;
  disabled: boolean;
  delay: number;
}) {
  const [focused, setFocused] = useState(false);

  return (
    <motion.div
      className="space-y-1.5"
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay, duration: 0.5 }}
    >
      <div className="relative group">
        <motion.div
          className="absolute inset-0 rounded-2xl pointer-events-none"
          animate={{
            boxShadow: focused
              ? '0 0 0 2px rgba(212,175,55,0.5), 0 0 20px rgba(212,175,55,0.15)'
              : '0 0 0 1px rgba(255,255,255,0.08)',
          }}
          transition={{ duration: 0.2 }}
        />
        <Icon
          className={`absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 transition-colors duration-300 z-10 ${
            focused ? 'text-yellow-400' : 'text-slate-500'
          }`}
        />
        <Input
          id={id}
          type={type}
          placeholder={placeholder}
          {...register}
          disabled={disabled}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          className="pr-12 h-13 rounded-2xl bg-slate-800/60 border-transparent text-white placeholder:text-slate-600 focus:border-transparent focus:ring-0 focus-visible:ring-0 focus-visible:ring-offset-0 text-base transition-all duration-300"
          style={{ height: '52px' }}
        />
      </div>
      <AnimatePresence>
        {error && (
          <motion.p
            className="text-xs text-red-400 pl-1"
            initial={{ opacity: 0, y: -5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
          >
            {error}
          </motion.p>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function FloatingLogo() {
  return (
    <motion.div
      className="flex justify-center mb-6"
      initial={{ opacity: 0, scale: 0.5, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ duration: 0.7, type: 'spring', stiffness: 200 }}
    >
      <div className="relative">
        <motion.div
          className="absolute inset-0 rounded-full"
          animate={{
            boxShadow: [
              '0 0 20px rgba(212,175,55,0.4)',
              '0 0 60px rgba(212,175,55,0.8)',
              '0 0 20px rgba(212,175,55,0.4)',
            ],
          }}
          transition={{ duration: 3, repeat: Infinity }}
        />
        <motion.div
          className="relative w-28 h-28 rounded-full overflow-hidden"
          animate={{ y: [0, -6, 0] }}
          transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
          style={{
            background:
              'radial-gradient(circle, rgba(212,175,55,0.15) 0%, rgba(0,0,0,0) 70%)',
            padding: '4px',
          }}
        >
          <div className="w-full h-full rounded-full overflow-hidden bg-transparent flex items-center justify-center">
            <Image
              src={LOGO_URL}
              alt="Jouw Driver Logo"
              width={112}
              height={112}
              className="object-contain w-full h-full"
              priority
            />
          </div>
        </motion.div>
        <motion.div
          className="absolute inset-[-8px] rounded-full border border-yellow-500/20"
          animate={{ rotate: 360 }}
          transition={{ duration: 12, repeat: Infinity, ease: 'linear' }}
          style={{ borderStyle: 'dashed' }}
        />
        <motion.div
          className="absolute inset-[-16px] rounded-full border border-yellow-500/10"
          animate={{ rotate: -360 }}
          transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
          style={{ borderStyle: 'dashed' }}
        />
      </div>
    </motion.div>
  );
}

function DriverGoogleLoginButton({
  onSuccess,
  onError,
  label,
  disabled,
}: {
  onSuccess: () => void;
  onError: (msg: string) => void;
  label: string;
  disabled: boolean;
}) {
  const { googleLogin } = useAuth();
  const [isLoading, setIsLoading] = useState(false);

  const handleClick = () => {
    if (typeof window === 'undefined' || disabled || isLoading) return;

    const windowWidth = 800;
    const windowHeight = 400;
    const url = `${process.env.NEXT_PUBLIC_ZOER_HOST}/auth/google/v1/login?fromUrl=${window.location.href}&appCode=${process.env.NEXT_PUBLIC_APP_CODE}`;

    const left = Math.floor((window.screen.width - windowWidth) / 2);
    const top = Math.floor((window.screen.height - windowHeight) / 2);
    const popupWindow = window.open(
      url,
      '_blank',
      `width=${windowWidth},height=${windowHeight},left=${left},top=${top},toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes`
    );

    if (!popupWindow) return;

    let closedCheckTimer: number | null = null;

    const onMessage = async (event: MessageEvent) => {
      if (event.source !== popupWindow) return;
      const data = event.data || {};
      const messageType = data.type || data.event || '';
      if (messageType !== 'zoer-google-login') return;

      setIsLoading(true);
      cleanup();

      try {
        await googleLogin(data.access_token);
        onSuccess();
      } catch {
        onError('Google login failed');
        setIsLoading(false);
      }
    };

    const cleanup = () => {
      window.removeEventListener('message', onMessage as unknown as EventListener);
      if (closedCheckTimer) {
        window.clearInterval(closedCheckTimer);
        closedCheckTimer = null;
      }
      try {
        popupWindow.close();
      } catch {}
      setIsLoading(false);
    };

    window.addEventListener('message', onMessage as unknown as EventListener);

    closedCheckTimer = window.setInterval(() => {
      if (popupWindow.closed) cleanup();
    }, 500);
  };

  return (
    <motion.button
      type="button"
      onClick={handleClick}
      disabled={disabled || isLoading}
      className="relative w-full h-14 rounded-2xl text-base font-semibold overflow-hidden flex items-center justify-center gap-3 disabled:opacity-60 disabled:cursor-not-allowed"
      style={{
        background: 'rgba(255,255,255,0.06)',
        border: '1px solid rgba(255,255,255,0.12)',
        color: '#e2e8f0',
        backdropFilter: 'blur(8px)',
      }}
      whileHover={{ scale: 1.01, background: 'rgba(255,255,255,0.1)' } as any}
      whileTap={{ scale: 0.98 }}
      transition={{ duration: 0.2 }}
    >
      {isLoading ? (
        <Loader2 className="w-5 h-5 animate-spin text-yellow-400" />
      ) : (
        <>
          <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
            <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
            <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
            <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
          </svg>
          <span>{label}</span>
        </>
      )}
    </motion.button>
  );
}

function DriverLoginContent() {
  const { language } = useLanguage();
  const t = driverTranslations[language];
  const router = useRouter();
  const searchParams = useSearchParams();
  const { user, isLoading: authLoading, refreshUser } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [particles] = useState(() => Array.from({ length: 20 }, (_, i) => i));

  const loginSchema = z.object({
    phone: z.string().min(8, t.phoneRequired),
    password: z.string().min(1, t.passwordRequired),
  });

  type LoginFormData = z.infer<typeof loginSchema>;

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
  });

  const handleRedirect = useCallback(() => {
    const redirectTo = searchParams.get('redirect') || '/driver/taximeter';
    router.replace(redirectTo);
  }, [searchParams, router]);

  useEffect(() => {
    if (!authLoading && user?.userType === 'driver') {
      handleRedirect();
    }
  }, [authLoading, user?.userType, handleRedirect]);

  const onSubmit = async (data: LoginFormData) => {
    try {
      setIsLoading(true);
      setError(null);
      await api.post('/auth/driver-login', {
        phone: data.phone?.trim(),
        password: data.password,
      });
      await refreshUser();
      handleRedirect();
    } catch (err: any) {
      setError(err?.errorMessage || t.loginError);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      className="relative flex flex-col justify-center items-center min-h-screen overflow-hidden"
      style={{
        background:
          'linear-gradient(135deg, #020817 0%, #0a0f1e 40%, #050d1a 70%, #020817 100%)',
      }}
    >
      <AnimatedGrid />

      <GlowOrb color="rgba(212,175,55,0.2)" size={500} top="-10%" left="-10%" delay={0} />
      <GlowOrb color="rgba(184,142,4,0.15)" size={400} top="60%" left="70%" delay={2} />
      <GlowOrb color="rgba(255,215,0,0.08)" size={300} top="40%" left="20%" delay={4} />

      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {particles.map((i) => (
          <Particle key={i} index={i} />
        ))}
      </div>

      <motion.div
        className="absolute top-6 left-0 right-0 flex justify-between items-center px-6 z-20"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl overflow-hidden bg-transparent flex items-center justify-center">
            <Image src={LOGO_URL} alt="Jouw Driver" width={32} height={32} className="object-contain w-full h-full" />
          </div>
          <span
            className="font-bold text-sm tracking-wide"
            style={{
              background: 'linear-gradient(90deg, #d4af37, #ffd700, #b8860b)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            Jouw Driver
          </span>
        </div>
        <LanguageToggle />
      </motion.div>

      <div className="relative z-10 w-full max-w-sm mx-4 mt-16">
        <FloatingLogo />

        <motion.div
          className="text-center mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.6 }}
        >
          <h1 className="text-3xl font-bold text-white mb-2 tracking-tight">
            {t.driverLogin}
          </h1>
          <p className="text-slate-400 text-sm">{t.driverAppSubtitle}</p>
        </motion.div>

        <motion.div
          className="flex justify-center gap-2 mb-6 flex-wrap"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <FeatureBadge icon={Shield} label="Secure" delay={0.5} />
          <FeatureBadge icon={Zap} label="Fast" delay={0.6} />
          <FeatureBadge icon={Star} label="Premium" delay={0.7} />
        </motion.div>

        <motion.div
          className="relative rounded-3xl overflow-hidden"
          initial={{ opacity: 0, y: 30, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ delay: 0.3, duration: 0.7, type: 'spring', stiffness: 150 }}
        >
          <div
            className="absolute inset-0 rounded-3xl pointer-events-none"
            style={{
              background:
                'linear-gradient(135deg, rgba(212,175,55,0.3) 0%, rgba(184,142,4,0.2) 50%, rgba(255,215,0,0.1) 100%)',
              padding: '1px',
            }}
          >
            <div className="absolute inset-[1px] rounded-3xl bg-slate-900/90" />
          </div>

          <div
            className="relative p-7"
            style={{
              background: 'rgba(15, 23, 42, 0.85)',
              backdropFilter: 'blur(24px)',
              border: '1px solid rgba(212,175,55,0.12)',
              borderRadius: '24px',
            }}
          >
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.45 }}
              className="mb-5"
            >
              <DriverGoogleLoginButton
                label={t.continueWithGoogle}
                disabled={isLoading}
                onSuccess={handleRedirect}
                onError={(msg) => setError(msg || t.googleLoginError)}
              />
            </motion.div>

            <motion.div
              className="flex items-center gap-3 mb-5"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
            >
              <div className="flex-1 h-px bg-white/10" />
              <span className="text-xs text-slate-500 uppercase tracking-wider">{t.orContinueWith}</span>
              <div className="flex-1 h-px bg-white/10" />
            </motion.div>

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
              <AnimatePresence>
                {error && (
                  <motion.div
                    className="flex items-center gap-3 p-3.5 rounded-2xl bg-red-500/10 border border-red-500/30"
                    initial={{ opacity: 0, height: 0, y: -10 }}
                    animate={{ opacity: 1, height: 'auto', y: 0 }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="w-2 h-2 rounded-full bg-red-400 flex-shrink-0 animate-pulse" />
                    <p className="text-sm text-red-300">{error}</p>
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="space-y-1.5">
                <motion.label
                  className="text-xs font-semibold text-slate-400 uppercase tracking-wider pl-1"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.55 }}
                >
                  {t.phoneNumber}
                </motion.label>
                <AnimatedInput
                  id="phone"
                  type="tel"
                  placeholder={t.phonePlaceholder}
                  icon={Phone}
                  register={register('phone')}
                  error={errors.phone?.message}
                  disabled={isLoading}
                  delay={0.55}
                />
              </div>

              <div className="space-y-1.5">
                <motion.label
                  className="text-xs font-semibold text-slate-400 uppercase tracking-wider pl-1"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.65 }}
                >
                  {t.password}
                </motion.label>
                <AnimatedInput
                  id="password"
                  type="password"
                  placeholder={t.passwordPlaceholder}
                  icon={Lock}
                  register={register('password')}
                  error={errors.password?.message}
                  disabled={isLoading}
                  delay={0.65}
                />
              </div>

              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.75 }}
              >
                <motion.button
                  type="submit"
                  disabled={isLoading}
                  className="relative w-full h-14 rounded-2xl text-base font-bold text-white overflow-hidden group disabled:opacity-70 disabled:cursor-not-allowed"
                  style={{
                    background:
                      'linear-gradient(135deg, #b8860b 0%, #d4af37 50%, #ffd700 100%)',
                    boxShadow:
                      '0 8px 32px rgba(212,175,55,0.4), 0 2px 8px rgba(0,0,0,0.3)',
                    color: '#1a1200',
                  }}
                  whileHover={{
                    scale: 1.02,
                    boxShadow: '0 12px 40px rgba(212,175,55,0.6)',
                  }}
                  whileTap={{ scale: 0.98 }}
                  transition={{ duration: 0.2 }}
                >
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -skew-x-12"
                    animate={{ x: ['-100%', '200%'] }}
                    transition={{ duration: 3, repeat: Infinity, repeatDelay: 2 }}
                  />
                  <span className="relative z-10 flex items-center justify-center gap-2 font-bold">
                    {isLoading ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        {t.loggingIn}
                      </>
                    ) : (
                      <>
                        {t.loginButton}
                        <motion.div
                          animate={{ x: [0, 4, 0] }}
                          transition={{ duration: 1.5, repeat: Infinity }}
                        >
                          <ChevronRight className="w-5 h-5" />
                        </motion.div>
                      </>
                    )}
                  </span>
                </motion.button>
              </motion.div>
            </form>

            <motion.div
              className="mt-5 flex items-center gap-2 p-3 rounded-xl bg-yellow-500/8 border border-yellow-500/20"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.9 }}
            >
              <Shield className="w-4 h-4 text-yellow-400 flex-shrink-0" />
              <p className="text-xs text-slate-400 leading-relaxed">{t.loginNotice}</p>
            </motion.div>
          </div>
        </motion.div>

        <motion.div
          className="flex justify-center mt-8 gap-1.5"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
        >
          {[0, 1, 2].map((i) => (
            <motion.div
              key={i}
              className="rounded-full"
              style={{
                width: i === 1 ? 24 : 6,
                height: 6,
                background: 'linear-gradient(90deg, #d4af37, #ffd700)',
                opacity: 0.4,
              }}
              animate={{ opacity: [0.4, 1, 0.4] }}
              transition={{ duration: 2, delay: i * 0.3, repeat: Infinity }}
            />
          ))}
        </motion.div>
      </div>
    </div>
  );
}

export default function DriverLoginPage() {
  return (
    <Suspense
      fallback={
        <div
          className="flex items-center justify-center min-h-screen"
          style={{ background: '#020817' }}
        >
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
          >
            <Loader2 className="w-10 h-10 text-yellow-500" />
          </motion.div>
        </div>
      }
    >
      <DriverLoginContent />
    </Suspense>
  );
}
