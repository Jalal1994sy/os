
import CrudOperations from '@/lib/crud-operations';
import { createSuccessResponse, createErrorResponse } from '@/lib/create-response';
import { parseQueryParams, getRequestIp } from "@/lib/api-utils";
import { generateAdminUserToken } from '@/lib/auth';

// GET - عرض الفاتورة للعميل (بدون تسجيل دخول)
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const share_token = searchParams.get('token');

  if (!share_token) {
    return createErrorResponse({
      errorMessage: "رمز المشاركة مطلوب",
      status: 400,
    });
  }

  try {
    const adminToken = await generateAdminUserToken();
    const shareLinksCrud = new CrudOperations("invoice_share_links", adminToken);
    const invoicesCrud = new CrudOperations("invoices", adminToken);
    const companiesCrud = new CrudOperations("companies", adminToken);
    const viewLogCrud = new CrudOperations("invoice_view_log", adminToken);
    
    // البحث عن رابط المشاركة
    const shareLinks = await shareLinksCrud.findMany({ share_token });
    
    if (!shareLinks || shareLinks.length === 0) {
      return createErrorResponse({
        errorMessage: "رابط غير صحيح أو منتهي الصلاحية",
        status: 404,
      });
    }

    const shareLink = shareLinks[0];

    // التحقق من أن الرابط نشط
    if (!shareLink.is_active) {
      return createErrorResponse({
        errorMessage: "هذا الرابط غير نشط",
        status: 403,
      });
    }

    // التحقق من انتهاء الصلاحية (إذا كان محدداً)
    if (shareLink.expires_at && new Date(shareLink.expires_at) < new Date()) {
      return createErrorResponse({
        errorMessage: "انتهت صلاحية هذا الرابط",
        status: 410,
      });
    }

    // جلب الفاتورة
    const invoice = await invoicesCrud.findById(shareLink.invoice_id);
    if (!invoice) {
      return createErrorResponse({
        errorMessage: "الفاتورة غير موجودة",
        status: 404,
      });
    }

    // جلب معلومات الشركة المصدرة
    const issuerCompany = await companiesCrud.findById(invoice.issuer_company_id);
    
    // جلب معلومات الشركة العميل (إذا كانت موجودة)
    let clientCompany = null;
    if (invoice.client_company_id) {
      clientCompany = await companiesCrud.findById(invoice.client_company_id);
    }

    // تسجيل المشاهدة
    const viewerIp = getRequestIp(request as any);
    const viewerUserAgent = request.headers.get('user-agent') || 'Unknown';
    
    await viewLogCrud.create({
      share_link_id: shareLink.id,
      invoice_id: invoice.id,
      viewer_ip: viewerIp,
      viewer_user_agent: viewerUserAgent
    });

    // تحديث عداد المشاهدات
    await shareLinksCrud.update(shareLink.id, {
      view_count: (shareLink.view_count || 0) + 1,
      last_viewed_at: new Date().toISOString()
    });

    // إرجاع بيانات الفاتورة
    return createSuccessResponse({
      invoice: {
        ...invoice,
        items: typeof invoice.items === 'string' ? JSON.parse(invoice.items) : invoice.items
      },
      issuer_company: issuerCompany,
      client_company: clientCompany,
      share_link: {
        qr_code_url: shareLink.qr_code_url,
        view_count: (shareLink.view_count || 0) + 1
      }
    });
  } catch (error: any) {
    console.error('Error viewing invoice:', error);
    return createErrorResponse({
      errorMessage: error.message || "فشل تحميل الفاتورة",
      status: 500,
    });
  }
}
