
import CrudOperations from '@/lib/crud-operations';
import { createErrorResponse } from '@/lib/create-response';
import { requestMiddleware, parseQueryParams } from "@/lib/api-utils";
import { generateAdminUserToken } from '@/lib/auth';
import { PDFGenerator } from '@/lib/pdf-generator';

export const POST = requestMiddleware(async (request, context) => {
  const { id: tripId } = parseQueryParams(request);

  if (!tripId) {
    return createErrorResponse({
      errorMessage: "معرف الرحلة مطلوب",
      status: 400,
    });
  }

  const user_id = context.payload?.sub;
  if (!user_id) {
    return createErrorResponse({
      errorMessage: "معرف المستخدم مطلوب",
      status: 400,
    });
  }

  try {
    const adminToken = await generateAdminUserToken();

    const tripsCrud = new CrudOperations("trips", adminToken);
    const trip = await tripsCrud.findById(tripId);

    if (!trip) {
      return createErrorResponse({
        errorMessage: "الرحلة غير موجودة",
        status: 404,
      });
    }

    if (trip.user_id !== parseInt(user_id)) {
      return createErrorResponse({
        errorMessage: "غير مصرح لك بالوصول لهذه الرحلة",
        status: 403,
      });
    }

    const companiesCrud = new CrudOperations("companies", adminToken);
    const company = await companiesCrud.findById(trip.company_id);

    if (!company) {
      return createErrorResponse({
        errorMessage: "معلومات الشركة غير موجودة",
        status: 404,
      });
    }

    const driversCrud = new CrudOperations("drivers", adminToken);
    const driver = await driversCrud.findById(trip.driver_id);

    if (!driver) {
      return createErrorResponse({
        errorMessage: "معلومات السائق غير موجودة",
        status: 404,
      });
    }

    const invoiceNumber = `TRIP-${trip.id}-${Date.now()}`;
    const paymentReference = PDFGenerator['generateStructuredReference'](invoiceNumber);

    const shareToken = `INV-${Date.now()}-${Math.random().toString(36).substring(2, 9).toUpperCase()}`;
    const shareUrl = `${process.env.NEXT_PUBLIC_APP_URL || 'https://app.example.com'}/invoice/${shareToken}`;
    const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(shareUrl)}`;

    // Use the actual trip end_time as the invoice date/time (fixes 00:00 issue)
    // Fall back to start_time if end_time is missing
    const invoiceDatetime = trip.end_time || trip.start_time || new Date().toISOString();

    const pdfData = {
      company: {
        id: company.id,
        name: company.name || 'شركة تاكسي',
        kbo_number: company.kbo_number || '',
        address: company.address || '',
        email: company.email || '',
        phone: company.phone || '',
        vat_number: company.vat_number || '',
        client_name: company.client_name || company.name || 'شركة تاكسي',
        bank_account_iban: company.bank_account_iban || 'BE16973450355674',
        bank_account_bic: company.bank_account_bic || 'ARSPBE22',
        bank_account_holder: company.bank_account_holder || company.name || 'شركة تاكسي'
      },
      driver: {
        id: driver.id,
        full_name: driver.full_name || 'سائق',
        capacity_certificate_number: driver.capacity_certificate_number || '',
        phone: driver.phone || ''
      },
      trip: {
        id: trip.id,
        start_time: trip.start_time || new Date().toISOString(),
        end_time: trip.end_time || new Date().toISOString(),
        start_address: trip.start_address || 'موقع غير محدد',
        end_address: trip.end_address || 'موقع غير محدد',
        distance_km: trip.distance_km || 0,
        duration_minutes: trip.duration_minutes || 0,
        price: trip.price || 0,
        passenger_name: trip.passenger_name || null,
        ritnummer: trip.ritnummer || `TRIP-${trip.id}`
      },
      invoiceNumber: invoiceNumber,
      // Pass the full ISO datetime string so the PDF generator can show correct time
      invoiceDate: invoiceDatetime,
      vatRate: 6,
      paymentReference: paymentReference,
      shareUrl: shareUrl,
      qrCodeUrl: qrCodeUrl
    };

    const pdf = PDFGenerator.generateTripInvoice(pdfData);
    const pdfBlob = PDFGenerator.getPDFBlob(pdf);

    const arrayBuffer = await pdfBlob.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    if (buffer.length === 0) {
      throw new Error('فشل في إنشاء ملف PDF');
    }

    try {
      const invoicesCrud = new CrudOperations("invoices", adminToken);
      const newInvoice = await invoicesCrud.create({
        user_id: parseInt(user_id),
        company_id: company.id,
        issuer_company_id: company.id,
        trip_id: trip.id,
        invoice_number: invoiceNumber,
        client_name: trip.passenger_name || 'عميل',
        client_address: trip.end_address || '',
        total_htva: (trip.price || 0) / 1.06,
        vat_rate: 6,
        total_tvac: trip.price || 0,
        invoice_date: new Date().toISOString().split('T')[0],
        status: 'sent',
        payment_status: 'pending',
        invoice_type: 'one_time',
        invoice_category: 'trip',
        items: JSON.stringify([{
          description: `Taxirit van ${trip.start_address} naar ${trip.end_address}`,
          quantity: 1,
          unitPrice: (trip.price || 0) / 1.06,
          total: (trip.price || 0) / 1.06
        }]),
        structured_reference: paymentReference
      });

      const shareLinksCrud = new CrudOperations("invoice_share_links", adminToken);
      await shareLinksCrud.create({
        invoice_id: newInvoice.id,
        share_token: shareToken,
        qr_code_url: qrCodeUrl,
        view_count: 0,
        is_active: true
      });
    } catch (error) {
      console.error('Error saving invoice share link:', error);
    }

    return new Response(buffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="Factuur-Rit-${trip.id}.pdf"`,
        'Content-Length': buffer.length.toString(),
        'Cache-Control': 'no-cache',
        'X-Share-URL': shareUrl,
        'X-QR-Code-URL': qrCodeUrl
      }
    });

  } catch (error: any) {
    console.error('Error generating invoice:', error);
    return createErrorResponse({
      errorMessage: error.message || "فشل إنشاء الفاتورة",
      status: 500,
    });
  }
}, true);
