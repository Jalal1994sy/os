
import CrudOperations from '@/lib/crud-operations';
import { createSuccessResponse, createErrorResponse } from '@/lib/create-response';
import { requestMiddleware, validateRequestBody } from "@/lib/api-utils";
import { generateAdminUserToken } from '@/lib/auth';

export const POST = requestMiddleware(async (request, context) => {
  const body = await validateRequestBody(request);
  const user_id = context.payload?.sub;

  if (!user_id) {
    return createErrorResponse({
      errorMessage: "User ID is required",
      status: 400,
    });
  }

  const { start_lat, start_lon, start_address } = body;

  if (!start_lat || !start_lon || !start_address) {
    return createErrorResponse({
      errorMessage: "Start location and address are required",
      status: 400,
    });
  }

  try {
    const adminToken = await generateAdminUserToken();
    const tripsCrud = new CrudOperations("trips", context.token);

    // Get driver info
    const driversCrud = new CrudOperations("drivers", adminToken);
    const drivers = await driversCrud.findMany({ user_id: parseInt(user_id) });
    
    if (!drivers || drivers.length === 0) {
      return createErrorResponse({
        errorMessage: "Driver profile not found",
        status: 404,
      });
    }

    const driver = drivers[0];

    const tripData = {
      user_id: parseInt(user_id),
      company_id: driver.company_id,
      driver_id: driver.id,
      vehicle_id: 1, // TODO: Get from driver's assigned vehicle
      start_time: new Date().toISOString(),
      start_lat,
      start_lon,
      start_address,
      status: 'in_progress',
      start_fee: 2.40,
      price_per_km: 1.80,
      waiting_fee: 0.00,
    };

    const data = await tripsCrud.create(tripData);
    return createSuccessResponse(data, 201);
  } catch (error: any) {
    console.error('Error starting trip:', error);
    return createErrorResponse({
      errorMessage: error.message || "Failed to start trip",
      status: 500,
    });
  }
}, true);
