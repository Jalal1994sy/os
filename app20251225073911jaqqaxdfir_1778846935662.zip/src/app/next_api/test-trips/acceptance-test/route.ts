
import { createSuccessResponse, createErrorResponse } from '@/lib/create-response';
import { requestMiddleware, validateRequestBody } from "@/lib/api-utils";
import { ChironService } from '@/lib/chiron-service';
import CrudOperations from '@/lib/crud-operations';
import { generateAdminUserToken } from '@/lib/auth';
import { PDFGenerator } from '@/lib/pdf-generator';
import { upload } from '@zoerai/integration';

/**
 * POST - تنفيذ اختبار القبول (5 VERTREK + 5 AANKOMST)
 * يستقبل company_id و driver_id و vehicle_id من الطلب
 * يحفظ تقرير PDF في قاعدة البيانات
 */
export const POST = requestMiddleware(async (request, context) => {
  try {
    const body = await validateRequestBody(request);
    const { company_id, driver_id, vehicle_id } = body;

    if (!company_id || !driver_id || !vehicle_id) {
      return createErrorResponse({
        errorMessage: "company_id و driver_id و vehicle_id مطلوبة",
        status: 400,
      });
    }

    const adminToken = await generateAdminUserToken();
    
    // التحقق من وجود الشركة
    const companiesCrud = new CrudOperations('companies', adminToken);
    const company = await companiesCrud.findById(company_id);
    
    if (!company) {
      return createErrorResponse({
        errorMessage: "الشركة غير موجودة",
        status: 404,
      });
    }

    // التحقق من وجود السائق
    const driversCrud = new CrudOperations('drivers', adminToken);
    const driver = await driversCrud.findById(driver_id);
    
    if (!driver) {
      return createErrorResponse({
        errorMessage: "لم يتم العثور على ملف السائق",
        status: 404,
      });
    }

    // التحقق من وجود المركبة
    const vehiclesCrud = new CrudOperations('vehicles', adminToken);
    const vehicle = await vehiclesCrud.findById(vehicle_id);
    
    if (!vehicle) {
      return createErrorResponse({
        errorMessage: "لم يتم العثور على المركبة",
        status: 404,
      });
    }

    console.log(`[Acceptance Test] Starting test for company ${company_id}, driver ${driver_id}, vehicle ${vehicle_id}`);

    // تنفيذ اختبار القبول
    const result = await ChironService.runAcceptanceTest(
      parseInt(company_id),
      parseInt(driver_id),
      parseInt(vehicle_id)
    );

    // توليد تقرير PDF
    let pdfUrl = null;
    try {
      const pdfDoc = PDFGenerator.generateAcceptanceTestReport({
        company: {
          id: company.id,
          name: company.name,
          kbo_number: company.kbo_number || '',
          address: company.address || '',
          email: company.email || '',
          phone: company.phone || '',
          vat_number: company.vat_number || '',
        },
        driver: {
          id: driver.id,
          full_name: driver.full_name,
          capacity_certificate_number: driver.capacity_certificate_number || '',
          phone: driver.phone || '',
        },
        vehicle: {
          id: vehicle.id,
          brand: vehicle.brand,
          model: vehicle.model,
          plate_number: vehicle.plate_number,
        },
        testDate: new Date().toISOString(),
        totalMessages: result.totalMessages,
        successCount: result.successCount,
        failedCount: result.failedCount,
        results: result.results
      });

      // تحويل PDF إلى Blob
      const pdfBlob = PDFGenerator.getPDFBlob(pdfDoc);
      
      // إنشاء File من Blob
      const pdfFile = new File(
        [pdfBlob], 
        `acceptance-test-${company_id}-${Date.now()}.pdf`,
        { type: 'application/pdf' }
      );

      // رفع PDF باستخدام uploadWithPresignedUrl
      const uploadResult = await upload.uploadWithPresignedUrl(pdfFile, {
        maxSize: 5 * 1024 * 1024, // 5MB
        allowedExtensions: ['.pdf']
      });

      if (uploadResult.success && uploadResult.url) {
        pdfUrl = uploadResult.url;
        console.log(`[Acceptance Test] PDF uploaded successfully: ${pdfUrl}`);
      } else {
        console.error(`[Acceptance Test] PDF upload failed: ${uploadResult.error}`);
      }
    } catch (pdfError: any) {
      console.error('[Acceptance Test] Error generating/uploading PDF:', pdfError);
      // نستمر حتى لو فشل توليد PDF
    }

    // حفظ التقرير في قاعدة البيانات
    const reportsCrud = new CrudOperations('acceptance_test_reports', adminToken);
    
    const reportData = {
      company_id: parseInt(company_id),
      driver_id: parseInt(driver_id),
      report_date: new Date().toISOString().split('T')[0],
      total_messages: result.totalMessages,
      success_count: result.successCount,
      failed_count: result.failedCount,
      vertrek_count: 5,
      aankomst_count: 5,
      test_trip_ids: JSON.stringify([]),
      report_status: result.success ? 'completed' : 'failed',
      report_pdf_url: pdfUrl,
      submitted_to_municipality: false,
      notes: result.success 
        ? 'Acceptance test completed successfully' 
        : `Test completed with ${result.failedCount} failures`
    };

    await reportsCrud.create(reportData);

    if (result.success) {
      return createSuccessResponse({
        message: "✅ تم إرسال جميع الرسائل التجريبية بنجاح إلى Chiron Test",
        pdfUrl,
        ...result
      }, 201);
    } else {
      return createSuccessResponse({
        message: "⚠️ تم إرسال الرسائل ولكن بعضها فشل",
        pdfUrl,
        ...result
      }, 200);
    }

  } catch (error: any) {
    console.error('Error running acceptance test:', error);
    return createErrorResponse({
      errorMessage: error.message || "فشل تنفيذ اختبار القبول",
      status: 500,
    });
  }
}, true);
