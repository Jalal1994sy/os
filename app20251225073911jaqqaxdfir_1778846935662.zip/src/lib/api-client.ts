
import { toast } from 'sonner';
import { AUTH_ENABLED, authConfig } from '../config/auth-config';
import { AUTH_CODE } from '@/constants/auth';

interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  message?: string;
  errorMessage?: string;
  errorCode?: string;
}

class ApiError extends Error {
  constructor(public status: number, public errorMessage: string, public errorCode?: string) {
    super(errorMessage);
    this.name = 'ApiError';
  }
}

// ============ Auth-enabled helpers ============
let isRefreshing = false;
let refreshPromise: Promise<boolean> | null = null;

async function refreshToken(): Promise<boolean> {
  try {
    const response = await fetch(authConfig.refreshPath, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      return false;
    }

    const result: ApiResponse = await response.json();
    return result.success === true;
  } catch (error) {
    return false;
  }
}

function getLoginPath(): string {
  if (typeof window === 'undefined') return authConfig.loginPath;
  const pathname = window.location.pathname;
  // For driver portal, redirect to driver-login instead of the default login
  if (pathname.startsWith('/driver')) {
    return '/driver-login';
  }
  return authConfig.loginPath;
}

function redirectToLogin() {
  if (typeof window !== 'undefined') {
    const currentPath = window.location.pathname;
    const loginPath = getLoginPath();
    if (currentPath === loginPath || currentPath === `${loginPath}/`) {
      return;
    }
    const loginUrl = `${loginPath}?redirect=${encodeURIComponent(currentPath)}`;
    window.location.href = loginUrl;
  }
}

// ============ API Request with conditional auth ============
async function apiRequest<T = any>(
  endpoint: string,
  options?: RequestInit,
  isRetry = false
): Promise<T> {
  try {
    const response = await fetch(`/next_api${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        ...options?.headers,
      },
      ...options,
    });

    const result: ApiResponse<T> = await response.json();

    // Auth-enabled: handle token missing
    if (AUTH_ENABLED && [AUTH_CODE.TOKEN_MISSING].includes(result.errorCode || '')) {
      throw new ApiError(401, 'need login', AUTH_CODE.TOKEN_MISSING);
    }

    // Auth-enabled: handle token expired with refresh
    if (
      AUTH_ENABLED &&
      response.status === 401 &&
      result.errorCode === AUTH_CODE.TOKEN_EXPIRED &&
      !isRetry
    ) {
      if (isRefreshing && refreshPromise) {
        const refreshSuccess = await refreshPromise;
        if (refreshSuccess) {
          return apiRequest<T>(endpoint, options, true);
        } else {
          throw new ApiError(401, 'need login', AUTH_CODE.TOKEN_EXPIRED);
        }
      }

      if (!isRefreshing) {
        isRefreshing = true;
        refreshPromise = refreshToken();

        try {
          const refreshSuccess = await refreshPromise;

          if (refreshSuccess) {
            return apiRequest<T>(endpoint, options, true);
          } else {
            throw new ApiError(401, 'need login', AUTH_CODE.TOKEN_EXPIRED);
          }
        } finally {
          isRefreshing = false;
          refreshPromise = null;
        }
      }
    }

    if (!response.ok || !result.success) {
      throw new ApiError(
        response.status,
        result.errorMessage || 'API request failed',
        result.errorCode
      );
    }

    return result.data as T;
  } catch (error) {
    if (error instanceof ApiError) {
      // Only redirect on 401 if we are in a browser context and not already on a login page
      if (error.status === 401 && typeof window !== 'undefined') {
        const loginPath = getLoginPath();
        const currentPath = window.location.pathname;
        const isOnLoginPage =
          currentPath === loginPath ||
          currentPath === '/login' ||
          currentPath === '/driver-login';

        if (!isOnLoginPage) {
          // For TOKEN_MISSING errors, redirect immediately
          if (error.errorCode === AUTH_CODE.TOKEN_MISSING) {
            redirectToLogin();
          }
        }
      }
      throw error;
    }
    console.error('API request error:', error);
    throw new ApiError(500, 'Network error or invalid response');
  }
}

export const api = {
  get: <T = any>(endpoint: string, params?: Record<string, string>) => {
    const url = params
      ? `${endpoint}?${new URLSearchParams(params).toString()}`
      : endpoint;
    return apiRequest<T>(url, { method: 'GET' });
  },

  post: <T = any>(endpoint: string, data?: any) =>
    apiRequest<T>(endpoint, {
      method: 'POST',
      body: data ? JSON.stringify(data) : undefined,
    }),

  put: <T = any>(endpoint: string, data?: any) =>
    apiRequest<T>(endpoint, {
      method: 'PUT',
      body: data ? JSON.stringify(data) : undefined,
    }),

  delete: <T = any>(endpoint: string) =>
    apiRequest<T>(endpoint, { method: 'DELETE' }),
};

export { ApiError };
export type { ApiResponse };
