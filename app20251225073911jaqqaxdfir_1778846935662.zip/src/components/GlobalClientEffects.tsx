

"use client";

import { useEffect } from "react";
import { usePathname } from "next/navigation";
import SiteAIAgent from "@/components/ai/SiteAIAgent";

export default function GlobalClientEffects() {
  const pathname = usePathname();

  // Hide the AI assistant inside the driver portal and on the driver login page.
  // It remains active on landing, admin, company, and distributor portals.
  const isDriverPortal =
    pathname === "/driver-login" || (pathname?.startsWith("/driver/") ?? false);

  useEffect(() => {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker
        .register("/sw.js", { scope: "/" })
        .then((registration) => {
          console.log("SW registered:", registration.scope);

          registration.addEventListener("updatefound", () => {
            const newWorker = registration.installing;
            if (newWorker) {
              newWorker.addEventListener("statechange", () => {
                if (newWorker.state === "installed" && navigator.serviceWorker.controller) {
                  console.log("New SW available");
                }
              });
            }
          });
        })
        .catch((err) => console.warn("SW registration failed:", err));
    }

    let lastTouchEnd = 0;
    const preventDoubleTapZoom = (e: TouchEvent) => {
      const now = Date.now();
      if (now - lastTouchEnd <= 300) {
        e.preventDefault();
      }
      lastTouchEnd = now;
    };
    document.addEventListener("touchend", preventDoubleTapZoom, { passive: false });

    let startY = 0;
    const onTouchStart = (e: TouchEvent) => {
      startY = e.touches[0]?.clientY || 0;
    };

    const preventPullToRefresh = (e: TouchEvent) => {
      if (e.touches.length !== 1) return;
      const touch = e.touches[0];
      const deltaY = touch.clientY - startY;
      if (deltaY > 0 && window.scrollY === 0) {
        e.preventDefault();
      }
    };

    document.addEventListener("touchstart", onTouchStart, { passive: true });
    document.addEventListener("touchmove", preventPullToRefresh, { passive: false });

    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === "SYNC_OFFLINE_TRIPS") {
        const offlineTrips = JSON.parse(localStorage.getItem("offline_trips") || "[]");
        if (offlineTrips.length > 0) {
          console.log("Syncing offline trips:", offlineTrips.length);
        }
      }
    };

    navigator.serviceWorker?.addEventListener("message", handleMessage);

    return () => {
      document.removeEventListener("touchend", preventDoubleTapZoom);
      document.removeEventListener("touchstart", onTouchStart);
      document.removeEventListener("touchmove", preventPullToRefresh);
      navigator.serviceWorker?.removeEventListener("message", handleMessage);
    };
  }, []);

  if (isDriverPortal) {
    return null;
  }

  return <SiteAIAgent />;
}

