
'use client';

import { motion, AnimatePresence } from 'framer-motion';
import Image from 'next/image';
import { useCallback, useEffect, useRef, useState } from 'react';

const LOGO_URL =
  'https://cdn.chat2db-ai.com/app/avatar/custom/16eda623-2b94-41ea-8390-395dcb708494_737955.png';

const MIN_DISPLAY_MS = 1500;
const MAX_DISPLAY_MS = 7000;

interface DriverSplashScreenProps {
  onComplete: () => void;
  isReady?: boolean;
}

// ---- Floating Particle ----
function Particle({ index }: { index: number }) {
  const size = Math.random() * 4 + 2;
  const duration = Math.random() * 15 + 10;
  const delay = Math.random() * 8;
  const x = Math.random() * 100;

  return (
    <motion.div
      className="absolute rounded-full pointer-events-none"
      style={{
        width: size,
        height: size,
        left: `${x}%`,
        bottom: '-10px',
        background:
          index % 3 === 0
            ? 'rgba(212,175,55,0.6)'
            : index % 3 === 1
            ? 'rgba(255,215,0,0.4)'
            : 'rgba(184,142,4,0.5)',
        boxShadow: `0 0 ${size * 2}px rgba(212,175,55,0.8)`,
      }}
      animate={{
        y: [0, -900],
        x: [0, (Math.random() - 0.5) * 120],
        opacity: [0, 0.8, 0.8, 0],
        scale: [0, 1, 1, 0],
      }}
      transition={{
        duration,
        delay,
        repeat: Infinity,
        ease: 'easeInOut',
      }}
    />
  );
}

// ---- Animated Grid ----
function AnimatedGrid() {
  return (
    <motion.div
      className="absolute inset-0 pointer-events-none"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 2 }}
    >
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage: `
            linear-gradient(rgba(212,175,55,0.5) 1px, transparent 1px),
            linear-gradient(90deg, rgba(212,175,55,0.5) 1px, transparent 1px)
          `,
          backgroundSize: '40px 40px',
        }}
      />
    </motion.div>
  );
}

// ---- Glow Orb ----
function GlowOrb({
  color,
  size,
  top,
  left,
  delay,
}: {
  color: string;
  size: number;
  top: string;
  left: string;
  delay: number;
}) {
  return (
    <motion.div
      className="absolute rounded-full pointer-events-none blur-3xl"
      style={{ width: size, height: size, top, left, background: color }}
      animate={{
        scale: [1, 1.3, 1],
        opacity: [0.3, 0.6, 0.3],
      }}
      transition={{ duration: 6, delay, repeat: Infinity, ease: 'easeInOut' }}
    />
  );
}

// ---- Rotating Ring ----
function RotatingRing({
  size,
  duration,
  reverse,
  opacity,
  dashed,
}: {
  size: number;
  duration: number;
  reverse?: boolean;
  opacity: number;
  dashed?: boolean;
}) {
  return (
    <motion.div
      className="absolute rounded-full border border-yellow-500 pointer-events-none"
      style={{
        width: size,
        height: size,
        opacity,
        borderStyle: dashed ? 'dashed' : 'solid',
        top: '50%',
        left: '50%',
        marginTop: -size / 2,
        marginLeft: -size / 2,
      }}
      animate={{ rotate: reverse ? -360 : 360 }}
      transition={{ duration, repeat: Infinity, ease: 'linear' }}
    />
  );
}

// ---- Progress Bar (indeterminate — no fixed duration) ----
function ProgressBar() {
  return (
    <motion.div
      className="w-48 h-1 rounded-full overflow-hidden"
      style={{ background: 'rgba(212,175,55,0.15)' }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.8 }}
    >
      <motion.div
        className="h-full rounded-full"
        style={{
          background: 'linear-gradient(90deg, #b8860b, #d4af37, #ffd700)',
          boxShadow: '0 0 12px rgba(212,175,55,0.8)',
          width: '45%',
        }}
        animate={{ x: ['-110%', '240%'] }}
        transition={{ duration: 1.3, repeat: Infinity, ease: 'easeInOut', repeatDelay: 0.1 }}
      />
    </motion.div>
  );
}

// ---- Loading Dots ----
function LoadingDots() {
  return (
    <div className="flex gap-2 items-center">
      {[0, 1, 2].map((i) => (
        <motion.div
          key={i}
          className="rounded-full"
          style={{
            width: i === 1 ? 24 : 8,
            height: 8,
            background: 'linear-gradient(90deg, #d4af37, #ffd700)',
          }}
          animate={{ opacity: [0.3, 1, 0.3], scale: [0.8, 1.1, 0.8] }}
          transition={{ duration: 1.2, delay: i * 0.2, repeat: Infinity }}
        />
      ))}
    </div>
  );
}

// ---- Main Splash Screen ----
export default function DriverSplashScreen({ onComplete, isReady }: DriverSplashScreenProps) {
  const [show, setShow] = useState(true);
  const [particles] = useState(() => Array.from({ length: 25 }, (_, i) => i));
  const mountTimeRef = useRef(Date.now());
  const dismissedRef = useRef(false);

  const dismiss = useCallback(() => {
    if (dismissedRef.current) return;
    dismissedRef.current = true;
    setShow(false);
    setTimeout(onComplete, 600);
  }, [onComplete]);

  // Safety: never show longer than MAX_DISPLAY_MS regardless of readiness
  useEffect(() => {
    const timer = setTimeout(dismiss, MAX_DISPLAY_MS);
    return () => clearTimeout(timer);
  }, [dismiss]);

  // Dismiss as soon as app signals ready, but respect MIN_DISPLAY_MS
  useEffect(() => {
    if (!isReady) return;
    const elapsed = Date.now() - mountTimeRef.current;
    const remaining = Math.max(0, MIN_DISPLAY_MS - elapsed);
    const timer = setTimeout(dismiss, remaining);
    return () => clearTimeout(timer);
  }, [isReady, dismiss]);

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.05 }}
          transition={{ duration: 0.6, ease: 'easeInOut' }}
          className="fixed inset-0 z-[9999] flex items-center justify-center overflow-hidden"
          style={{
            background:
              'linear-gradient(135deg, #020817 0%, #0a0f1e 40%, #050d1a 70%, #020817 100%)',
          }}
        >
          {/* Animated Grid */}
          <AnimatedGrid />

          {/* Glow Orbs */}
          <GlowOrb color="rgba(212,175,55,0.2)" size={500} top="-10%" left="-10%" delay={0} />
          <GlowOrb color="rgba(184,142,4,0.15)" size={400} top="60%" left="70%" delay={2} />
          <GlowOrb color="rgba(255,215,0,0.08)" size={300} top="40%" left="20%" delay={4} />

          {/* Floating Particles */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            {particles.map((i) => (
              <Particle key={i} index={i} />
            ))}
          </div>

          {/* Main Content */}
          <div className="relative z-10 flex flex-col items-center gap-8">

            {/* Logo Section */}
            <motion.div
              className="relative flex items-center justify-center"
              initial={{ opacity: 0, scale: 0.3, y: 40 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 0.9, type: 'spring', stiffness: 180, damping: 18 }}
            >
              {/* Rotating Rings */}
              <RotatingRing size={200} duration={12} opacity={0.15} dashed />
              <RotatingRing size={170} duration={8} reverse opacity={0.2} dashed />
              <RotatingRing size={145} duration={20} opacity={0.1} />

              {/* Pulsing Glow */}
              <motion.div
                className="absolute rounded-full blur-2xl"
                style={{
                  width: 130,
                  height: 130,
                  background: 'radial-gradient(circle, rgba(212,175,55,0.5), rgba(212,175,55,0))',
                }}
                animate={{
                  scale: [1, 1.4, 1],
                  opacity: [0.4, 0.9, 0.4],
                }}
                transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
              />

              {/* Logo Container */}
              <motion.div
                className="relative w-32 h-32 rounded-full overflow-hidden flex items-center justify-center"
                animate={{ y: [0, -8, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                style={{
                  background: 'rgba(15,23,42,0.6)',
                  border: '1px solid rgba(212,175,55,0.25)',
                  backdropFilter: 'blur(12px)',
                  boxShadow:
                    '0 0 40px rgba(212,175,55,0.3), inset 0 0 20px rgba(212,175,55,0.05)',
                }}
              >
                <Image
                  src={LOGO_URL}
                  alt="Jouw Driver Logo"
                  width={120}
                  height={120}
                  className="object-contain w-full h-full p-2"
                  priority
                />
              </motion.div>

              {/* Orbiting Dot */}
              <motion.div
                className="absolute"
                style={{ width: 170, height: 170 }}
                animate={{ rotate: 360 }}
                transition={{ duration: 5, repeat: Infinity, ease: 'linear' }}
              >
                <div
                  className="absolute top-0 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full"
                  style={{
                    background: 'linear-gradient(135deg, #d4af37, #ffd700)',
                    boxShadow: '0 0 10px rgba(212,175,55,1)',
                    marginTop: '-6px',
                  }}
                />
              </motion.div>
            </motion.div>

            {/* Brand Name */}
            <motion.div
              className="text-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.7 }}
            >
              <motion.h1
                className="text-5xl font-black tracking-tight mb-2"
                style={{
                  background: 'linear-gradient(90deg, #b8860b 0%, #d4af37 40%, #ffd700 70%, #d4af37 100%)',
                  backgroundSize: '200% 100%',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text',
                }}
                animate={{ backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'] }}
                transition={{ duration: 4, repeat: Infinity, ease: 'linear' }}
              >
                Jouw Driver
              </motion.h1>

              <motion.p
                className="text-sm font-medium tracking-widest uppercase"
                style={{ color: 'rgba(212,175,55,0.5)' }}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.9 }}
              >
                Chauffeur Portal
              </motion.p>
            </motion.div>

            {/* Glass Info Card */}
            <motion.div
              className="flex items-center gap-3 px-6 py-3 rounded-2xl"
              style={{
                background: 'rgba(15,23,42,0.7)',
                border: '1px solid rgba(212,175,55,0.15)',
                backdropFilter: 'blur(16px)',
                boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
              }}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.6 }}
            >
              <motion.div
                className="w-2 h-2 rounded-full"
                style={{ background: '#d4af37', boxShadow: '0 0 8px rgba(212,175,55,1)' }}
                animate={{ opacity: [1, 0.3, 1] }}
                transition={{ duration: 1.2, repeat: Infinity }}
              />
              <span className="text-xs text-slate-400 font-medium tracking-wide">
                Système de Gestion de Taxi Professionnel
              </span>
            </motion.div>

            {/* Progress Bar */}
            <motion.div
              className="flex flex-col items-center gap-3"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1 }}
            >
              <ProgressBar />
              <LoadingDots />
            </motion.div>
          </div>

          {/* Bottom Gradient Overlay */}
          <motion.div
            className="absolute bottom-0 left-0 right-0 h-1/3 pointer-events-none"
            style={{
              background:
                'linear-gradient(to top, rgba(212,175,55,0.06), transparent)',
            }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 1 }}
          />

          {/* Top Gradient Overlay */}
          <motion.div
            className="absolute top-0 left-0 right-0 h-1/4 pointer-events-none"
            style={{
              background:
                'linear-gradient(to bottom, rgba(212,175,55,0.04), transparent)',
            }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 1 }}
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
}
